const express = require("express");
const mysql2 = require("mysql2");
const bodyParser = require("body-parser");
const cors = require("cors");

// Create a new express application
const app = express();

// Enable CORS for all origins
app.use(cors());

// Middleware to parse incoming JSON request bodies
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Setup the MySQL connection
const db = mysql2.createConnection({
  host: "localhost",
  user: "root", // Replace with your MySQL username
  password: "", // Replace with your MySQL password
  database: "feedback_system",
});

// Connect to the MySQL database
db.connect((err) => {
  if (err) throw err;
  console.log("Connected to the MySQL database!");
});

// Route for user signup
app.post("/signup", async (req, res) => {
  const { name, email, password } = req.body;

  // Validate input
  if (!name || !email || !password) {
    return res.status(400).json({ message: "All fields are required!" });
  }

  // Check if email already exists
  const checkQuery = "SELECT * FROM users WHERE email = ?";
  db.query(checkQuery, [email], async (err, result) => {
    if (err) {
      console.error("Error checking email:", err);
      return res.status(500).json({ message: "Error checking email" });
    }
    if (result.length > 0) {
      return res.status(400).json({ message: "Email already exists!" });
    }

    // Insert user into database
    const query = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    db.query(query, [name, email, password], (err) => {
      if (err) {
        console.error("Error creating user:", err);
        return res.status(500).json({ message: "Error creating user" });
      }
      res.status(201).json({ message: "User created successfully!" });
    });
  });
});

// Route for user login
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  const query = "SELECT id, name, password FROM users WHERE email = ?";
  db.query(query, [email], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "An error occurred." });
    }

    if (results.length === 0) {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    const user = results[0];

    // Check password
    if (user.password !== password) {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    // Send user ID and name on successful login
    res.status(200).json({
      userId: user.id,
      userName: user.name,
      message: "Login successful!",
    });
  });
});

// Route to handle feedback submission
app.post("/submit-feedback", (req, res) => {
  const { userId, feedbackType, emoji, comments } = req.body;

  // Validate input
  if (!userId || !feedbackType || !comments) {
    return res.status(400).json({ message: "All fields are required!" });
  }

  // Insert feedback into MySQL database
  const query =
    "INSERT INTO feedback (user_id, feedback_type, emoji, comments) VALUES (?, ?, ?, ?)";
  db.query(query, [userId, feedbackType, emoji, comments], (err) => {
    if (err) {
      console.error("Error inserting feedback:", err);
      return res.status(500).json({ message: "Error saving feedback" });
    }
    res.status(200).json({ message: "Feedback submitted successfully!" });
  });
});

// Start the server on port 3000
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
